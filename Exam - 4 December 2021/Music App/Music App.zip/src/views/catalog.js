import { html } from "../../node_modules/lit-html/lit-html.js"
import { getOffers } from "../data/offers.js"
//TODO replace with actual template

const catalogTemplate = (albums,ctx) => html`
 <section id="catalogPage">
            <h1>All Albums</h1>

            
              ${albums.length >0 ? html`${albums.map(albumTemplate)}`:html`<p>No Albums in Catalog!</p>`}
            
        </section>`

const albumTemplate = (album) => html`
   <div class="card-box">
      <img src="${album.imgUrl}">
                <div>
                    <div class="text-center">
                        <p class="name">Name: ${album.name}</p>
                        <p class="artist">Artist: ${album.artist}</p>
                        <p class="genre">Genre: ${album.genre}</p>
                        <p class="price">Price: $${album.price}</p>
                        <p class="date">Release Date: ${album.releaseDate}</p>
                    </div>
                    ${JSON.parse(sessionStorage.getItem('userData'))? html`<div class="btn-group">
                        <a href="/catalog/${album._id}" id="details">Details</a>
                    </div>`:null}
                   
                </div>
    </div>
   `
export async function catalogPage(ctx) {
  const albums = await getOffers()
  
  console.log(albums)
  ctx.render(catalogTemplate(albums,ctx))
}