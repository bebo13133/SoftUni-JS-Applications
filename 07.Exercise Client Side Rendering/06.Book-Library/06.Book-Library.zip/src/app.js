import { html, render } from '../node_modules/lit-html/lit-html.js';
import { mainTemplate } from './templates/mainTemplates.js';
import { createBooks, deleteBooks, getBooks } from './api.js'
import { tableRowsTemplate } from './templates/tableRowsTemplate.js';

const root = document.body
render(mainTemplate(), root)
document.querySelector('#loadBooks').addEventListener('click', async (e) => {
    const dataBooks = await getBooks()

    const tableBody = document.querySelector('table tbody')

    const books = []

    for (const id in dataBooks) {
        books.push({
            author: dataBooks[id].author,
            title: dataBooks[id].title,
            _id: id
        })      
    }
  const ctx = {
    books, 
    onDelete,
    onEdit,
  }
    render(tableRowsTemplate(ctx), tableBody)
})

const addForm = document.querySelector('#add-form')
addForm.addEventListener('submit', async (e)=>{
    e.preventDefault()
    const formData = new FormData(e.target)
    const title = formData.get('title')
    const author = formData.get('author')

    const dataBooks = {
        title: title,
        author: author
    }
    await createBooks(dataBooks)
    addForm.reset()
    document.querySelector('#loadBooks').click()
})

function onDelete(id){
    deleteBooks(id)
    document.querySelector('#loadBooks').click()

}

async function onEdit(id){
    console.log('')
}