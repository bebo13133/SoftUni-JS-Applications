const form = document.querySelector('form')
document.getElementById('user').style.display = 'none'
const active = document.querySelectorAll("a").forEach(el => {
    el.classList.remove('active')
    document.querySelector('a#login').classList.add('active')
})


form.addEventListener('submit', (e) => {
    e.preventDefault()


    const formData = new FormData(e.target);
    const forms = Object.fromEntries(formData)
    if (!forms.email || !forms.password) {
        document.querySelector('p.notification').textContent = 'Email or password is required'
    
        setTimeout(() => {
            document.querySelector('p.notification').textContent = ""
            e.target.reset()

        }, 2000)
    } else {
        onLogin([...formData.entries()].reduce((a, [k, v]) => Object.assign(a, { [k]: v }), {}))
    }
});


async function onLogin(data) {
    const url = `http://localhost:3030/users/login`;

    const body = { email: data.email, password: data.password }

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {'Content-Type': "application/json"},
            body: JSON.stringify(body)
        },
      
        )
        const data = await response.json()
        console.log(data)
        if (response.status !== 200) throw new Error(data.message)
        sessionStorage.setItem('dataUser', JSON.stringify({
            email: data.email,
            accessToken: data.accessToken,
            id: data._id
        }))
window.location = '/src/index.html'

    } catch (e) {
        document.querySelector('p.notification').textContent = e
        setTimeout(() => {
            document.querySelector('p.notification').textContent = ""
        }, 2000)
        form.reset()
    }

}
